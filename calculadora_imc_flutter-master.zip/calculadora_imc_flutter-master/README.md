# cauculadora_de_imc

Aplicativo desenvolvido em Flutter

## 

Projeto: uma calculadora de IMC desenvolvida em Dart / Flutter para o curso de desenvolvimento de aplicativos da para dispositivos moveis.
