package br.com.andreson.cauculadora_de_imc

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
